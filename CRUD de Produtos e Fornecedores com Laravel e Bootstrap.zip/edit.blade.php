@extends('layouts.app')

@section('title', 'Editar Fornecedor')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-white">
                <h4 class="mb-0">Editar Fornecedor: {{ $fornecedor->nome }}</h4>
            </div>
            <div class="card-body">
                <form action="{{ route('fornecedores.update', $fornecedor) }}" method="POST">
                    @csrf
                    @method('PUT')
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome do Fornecedor</label>
                        <input type="text" class="form-control @error('nome') is-invalid @enderror" id="nome" name="nome" value="{{ old('nome', $fornecedor->nome) }}" required>
                    </div>
                    <div class="mb-3">
                        <label for="cnpj" class="form-label">CNPJ</label>
                        <input type="text" class="form-control @error('cnpj') is-invalid @enderror" id="cnpj" name="cnpj" value="{{ old('cnpj', $fornecedor->cnpj) }}" required>
                    </div>
                    <div class="mb-3">
                        <label for="contato" class="form-label">Contato</label>
                        <input type="text" class="form-control @error('contato') is-invalid @enderror" id="contato" name="contato" value="{{ old('contato', $fornecedor->contato) }}" required>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="{{ route('fornecedores.index') }}" class="btn btn-secondary">Voltar</a>
                        <button type="submit" class="btn btn-primary">Atualizar Fornecedor</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
