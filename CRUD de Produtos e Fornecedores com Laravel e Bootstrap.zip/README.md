# Sistema de Gestão de Produtos e Fornecedores

Este é um projeto acadêmico desenvolvido como parte da disciplina de Desenvolvimento Web, utilizando o framework **Laravel**. O sistema consiste em um CRUD (Create, Read, Update, Delete) completo para o gerenciamento de produtos e seus respectivos fornecedores.

## 👥 Alunos Responsáveis

*   **Leonardo Estevão Alves** — R.A: 00250458-1
*   **Vinicius Correia de Andrade** — R.A: 251953-1

## 🎯 Objetivo do Projeto

Desenvolver uma aplicação web robusta seguindo o padrão de arquitetura **MVC** (Model-View-Controller), garantindo a organização do código e a correta implementação de relacionamentos entre entidades no banco de dados.

## 🛠️ Tecnologias Utilizadas

*   **Framework:** Laravel 10.x
*   **Linguagem:** PHP 8.1+
*   **Banco de Dados:** SQLite (configurado via Migrations)
*   **Front-end:** Blade Templates + Bootstrap 5
*   **Gerenciador de Dependências:** Composer

## 📌 Funcionalidades

### 🏢 Gestão de Fornecedores
*   Cadastro de fornecedores (Nome, CNPJ, Contato).
*   Listagem e edição de dados.
*   Exclusão de fornecedores (com remoção em cascata de produtos vinculados).

### 🧾 Gestão de Produtos
*   Cadastro de produtos (Nome, Descrição, Preço).
*   Vínculo obrigatório com um fornecedor (Relacionamento 1:N).
*   Listagem detalhada com exibição do fornecedor responsável.
*   Edição e exclusão de produtos.

## 🚀 Como Instalar e Rodar o Projeto

### Pré-requisitos
*   PHP 8.1 ou superior
*   Composer instalado
*   Extensão SQLite do PHP habilitada

### Passo a Passo

1.  **Clonar o repositório:**
    ```bash
    git clone <url-do-repositorio>
    cd sistema-produtos-fornecedores
    ```

2.  **Instalar dependências:**
    ```bash
    composer install
    ```

3.  **Configurar o ambiente:**
    O arquivo `.env` já está incluso nesta versão acadêmica. Caso precise recriar o banco SQLite:
    ```bash
    touch database/database.sqlite
    ```

4.  **Gerar chave da aplicação:**
    ```bash
    php artisan key:generate
    ```

5.  **Executar as Migrations:**
    ```bash
    php artisan migrate
    ```

6.  **Iniciar o servidor local:**
    ```bash
    php artisan serve
    ```
    Acesse em seu navegador: `http://localhost:8000`

## 🧠 Boas Práticas Implementadas

*   **Arquitetura MVC:** Separação clara entre lógica de negócio, persistência de dados e interface.
*   **Migrations:** Controle de versão do banco de dados.
*   **Eloquent ORM:** Uso de relacionamentos nativos do Laravel (`belongsTo` e `hasMany`).
*   **Validação de Dados:** Regras de validação implementadas nos Controllers para garantir a integridade das informações.
*   **Blade Layouts:** Uso de herança de templates para reaproveitamento de código (Navbar e Footer).

---
*Projeto desenvolvido para fins acadêmicos.*
